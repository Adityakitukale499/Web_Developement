// Q. reverse Array
let myArray = [1, 2, 3, 4, 5];
 
console.log(myArray.reverse());

//Output : [5, 4, 3, 2, 1]
