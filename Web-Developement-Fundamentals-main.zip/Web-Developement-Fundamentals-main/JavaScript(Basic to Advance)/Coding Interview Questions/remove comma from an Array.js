// Q. remove comma from an Array
var testarray = new Array("a", "b", "c");
var str = "";
for (var i = 0; i < testarray.length; i++) {
    str += testarray[i] + " ";
}
console.log(str);
// Output : a b c
