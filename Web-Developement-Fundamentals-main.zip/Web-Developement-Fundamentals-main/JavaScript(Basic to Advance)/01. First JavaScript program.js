// first program of JS 
// in console we can use either ""/''/`` all will work 
// ->> this is comments which are not executed 
console.log("hello world");
