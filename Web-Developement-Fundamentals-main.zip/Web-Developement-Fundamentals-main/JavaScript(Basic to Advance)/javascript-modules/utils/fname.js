const firstName = "John";

export{firstName}