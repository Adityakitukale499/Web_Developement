export const age = 22;
export const hobby = "gyming";